
$(document).ready(function () {
    let btn0 = $('#btn0')

    btn0.on("click", function () {
        console.log("success_click")

        let selectcheck = document.getElementById("selectvalue");
        let selectcheckval = selectcheck.options[selectcheck.selectedIndex].value;

        if (selectcheckval == "state1") {
            console.log("success_state1")
            $.ajax({
                method: "POST",
                url: "studentReviewList.re",
                dataType: "json",
                succcess: (function (data) {
                    consolo.log(data)
                    if (data.length > 0) {
                        for (let i in data) {
                            let username = data[i].memberName;
                            let booktitle = data[i].bookName;
                            let reviewdate = data[i].reviewDate;
                            let examination = data[i].checkNo;
                            let usernum = data[i].memberNo;
                            let reviewnum = data[i].reviewNo;

                            $("#article1-3-1-1-0").append("<div id='article1-3-1-2' class='rewritebook'><div><p class='fontstyle8'>" + data[i].memberName + "</p></div><div><p class='fontstyle8'>" + booktitle + "</p></div><div><p class='fontstyle8'>" + data[i].reviewDate + "</p></div><div><p class='fontstyle8'>" + data[i].checkNo + "</p></div></div>")
                        }
                    }
                })
            })
        }       //if문 ENd

    })

});


/*
$(document).ready(function () {
    let btn1 = $('#btn1')


    btn1.on("click", function() {
        for (i = 2; i <= 11; i++) {
            $('#article1-3-1-0')
                .append('<div class="rewritebook" id="article1-3-1-' + i + '"></div>');
        }

        $.ajax({
            method: "POST",
            url: "ListVo.java",
            dataType: "json",
            succcess: (function (data) {
                consolo.log("data")
                if (data.length > 0) {
                    for (let i in data) {
                        let username = data[i].memberName;
                        let booktitle = data[i].bookName;
                        let reviewdate = data[i].reviewDate;
                        let examination = data[i].checkNo;
                        let usernum = data[i].memberNo;
                        let reviewnum = data[i].reviewNo;

                        $("#article1-3-1-1-0 .rewritebook").append("<div id='article1-3-1-1-0'><div id='article1-3-1-2' class='rewritebook'><div><p class='fontstyle8'>" + data[i].memberName + "</p></div><div><p class='fontstyle8'>" + booktitle + "</p></div><div><p class='fontstyle8'>" + data[i].reviewDate + "</p></div><div><p class='fontstyle8'>" + data[i].checkNo + "</p></div></div></div>")
                    }
                }
            })
        })
    })

});
*/

/*
window.onload = function () {

    let article321 = document.getElementById("article1-3-1");
    let article322 = document.getElementById("article1-3-2");
    let btn0 = document.getElementById("btn0");

    btn0.addEventListener('click', checkstate);

    function checkstate() {
        let selectcheck = document.getElementById("selectvalue");
        let selectcheckval = selectcheck.options[selectcheck.selectedIndex].value;

        if (selectcheckval == "state1") { article321.style.display = "block" } else { article321.style.display = "none" };
        if (selectcheckval == "state2") { article322.style.display = "block" } else { article322.style.display = "none" };
    }
}



$(function click() {
    for (i = 1; i <= 10; i++) {
    $('#article1-3-1-2')
    .append('<a href="bookNote.html"><div class="article2-1-1 product' + i + '"></div></a>');
}
*/
