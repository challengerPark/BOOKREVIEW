
$(document).ready(function () {
    let btn1 = $('#btn1')

    btn1.on("click", function() {
        let selectcheck = document.getElementById("selectvalue");
        let selectcheckval = selectcheck.options[selectcheck.selectedIndex].value;

        if (selectcheckval == "state1") {

        $.ajax({
            method: "POST",
            url: "studentReviewList.re",
            dataType: "json",
            succcess: (function (data) {
                consolo.log("data")
                if (data.length > 0) {
                    for (let i in data) {
                        let username = data[i].memberName;
                        let booktitle = data[i].bookName;
                        let reviewdate = data[i].reviewDate;
                        let examination = data[i].checkNo;  //1~3교사용은 select로 진행하기
                        let usernum = data[i].memberNo;
                        let reviewnum = data[i].reviewNo;

                        $("#article1-3-2-0").append("<div id='article1-3-2-2' class='rewritebook'><div><p class='fontstyle8'>" + data[i].memberName + "</p></div><div><p class='fontstyle8'>" + booktitle + "</p></div><div><p class='fontstyle8'>" + data[i].reviewDate + "</p></div><div><p class='fontstyle8'>" + data[i].checkNo + "</p></div></div>")
                    }
                }
            })
        })
    }       //if문 END
    })

});
